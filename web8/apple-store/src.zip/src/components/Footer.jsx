export default function Footer() {
  return (
    <footer className="bg-light text-center text-muted py-4 mt-auto border-top">
      <small>© Demo Apple Store — for learning only.</small>
    </footer>
  );
}
